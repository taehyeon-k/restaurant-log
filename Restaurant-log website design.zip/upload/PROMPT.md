# 붙여 쓰는 프롬프트

아래 블록을 그대로 복사해서 코딩 에이전트(Claude Code, Cursor 등)에 주면 됩니다.
`HANDOFF.md` 와 `dinary-map.js` 를 같은 폴더에 두거나 저장소에 함께 올려두세요.

---

```
저장소 taehyeon-k/restaurant-log (branch main, Next.js + TypeScript) 에
디자인 수정 8가지를 반영해줘. 상세 명세는 HANDOFF.md 에 있고, 색·글꼴·크기 값은
거기 적힌 토큰을 그대로 써. 참고 구현은 dinary-map.js (지도 어댑터) 야.

작업 순서:

1. 기록 작성·수정 폼에 '재방문' 스위치를 추가해.
   src/app/_components/mobile/EditScreen.tsx 와 데스크톱 기록 폼 둘 다.
   폼 상태에 revisit: boolean 을 넣고 insert/update payload 에 함께 보내.
   DB 컬럼은 이미 있으니 스키마는 그대로. 별점·가격 아래, 키워드 위에
   44x24 스위치 한 줄로. 기본값 꺼짐, 수정할 때는 저장된 값이 올라와야 해.

2. 지도의 상호·시설 이름을 없애.
   NEXT_PUBLIC_NAVER_MAP_KEY 가 있으면 네이버 지도
   (https://oapi.map.naver.com/openapi/v3/maps.js?ncpKeyId=KEY) 로,
   없으면 CARTO light_nolabels 타일로 떨어지게 만들어.
   dinary-map.js 가 두 지도를 같은 API 로 감싼 어댑터니까 그걸 TS 로 옮겨서
   MapPane.tsx 와 mobile/MobileMap.tsx 가 함께 쓰게 해. 지도 위 글자는
   우리 핀 이름표만 남아야 해.

3. 모바일 시트 머리를 두 줄로 줄여. (MobileShell.tsx)
   - 맛집/카페 세그먼트 줄 삭제. 대신 FilterSheet.tsx 맨 위에 '종류' 그룹으로
     맛집/카페 단일 선택을 넣어서 기능은 남겨.
   - 첫 줄: 왼쪽 '맛집 기록' + 곳 수, 오른쪽에 기록 검색 입력(flex:1).
   - 둘째 줄: 왼쪽 최근순/별점순/가격순, 오른쪽 끝에 '필터' 버튼.

4. 라벨첩 배지를 도장 하나로 통일해. (LabelBook.tsx, lib/labels.ts)
   라벨마다 다른 클립패스를 없애고, 92px conic-gradient 진행 고리 +
   84px 원 + 안쪽 점선 테두리 + Gowun Batang 한 글자 글리프로.
   획득은 색 채움, 미획득은 회색 + 진행도 N/M.

5. 핀 이름표는 zoom >= 15 에서만 보이게 해.
   확대가 바뀌면 이름표의 display 만 토글하고 마커를 다시 만들지 마
   (깜빡임). 데스크톱·모바일 같은 기준값. 선택된 핀은 예외로 항상 보여도 돼.

6. 지도 위 '+ 여기에 기록 추가' 말풍선을 누를 수 있게 해.
   기록 없는 검색 결과의 점선 핀 말풍선을 클릭하면 검색 결과 목록의 버튼과
   똑같은 기록 작성 폼이 이름·주소·좌표가 채워진 상태로 열려야 해.
   Leaflet 이면 bindTooltip 에 interactive: true 를 주고 말풍선 DOM 에
   click 리스너를 달아.

7. 메뉴 입력을 여러 줄로 바꿔.
   폼 상태 menu: string 을 menus: {name, price}[] 로. 한 줄은 이름 입력(flex:1) +
   96px 가격 입력(숫자만, 천 단위 쉼표, 오른쪽에 '원') + 두 줄 이상일 때 ✕ 삭제.
   아래에 점선 '+ 메뉴 추가' 버튼. '메뉴' 라벨 오른쪽에 '2개 · 20,000원' 합계.
   저장할 때 menu 컬럼에는 이름만 ", " 로 이어붙이고 price_range 에는 가격 합계를 넣어
   (기존 목록/카드가 그대로 동작하게). 수정할 때는 저장된 menu 문자열을 잘라서 되살려.

8. 배지를 라벨마다 다른 모양 + 선 그림으로 바꿔. (한자 전부 제거)
   HANDOFF.md 8번의 표대로 아홉 라벨에 각각 모양(원/톱니/방패/꽃/육각/사발/달/아치/팔각)과
   32x32 인라인 SVG 그림(젓가락·체크·가게·별·핀·그릇·초승달·달력·화살표)을 줘.
   stroke: currentColor 로 두고 획득/미획득 색은 부모가 정하게. 미획득은
   conic-gradient 진행 고리 + 회색. 이모지·아이콘폰트 금지, 인라인 SVG만.

지킬 것:
- 기존 색·글꼴·간격 토큰만 쓰고 새 색을 만들지 마.
- 모바일 터치 대상 최소 44px, 본문 11.5px 이상.
- 이모지 쓰지 마. 아이콘은 인라인 SVG 로만.
- 각 항목을 따로 커밋하고, HANDOFF.md 마지막의 확인 목록으로 스스로 점검해줘.
- 2번의 네이버 키는 내가 NCP 콘솔에서 발급하고 서비스 URL을 등록해야 하니,
  키가 없을 때도 앱이 정상 동작하는지 꼭 확인해줘.
```
