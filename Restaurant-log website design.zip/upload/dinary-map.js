/* DINARY 지도 어댑터
 * naverKey 를 주면 네이버 지도로, 없으면 같은 모양의 종이색 타일 지도로 그립니다.
 * 두 경우 모두 핀 모양·이름표·클릭 동작이 같습니다.
 *   const map = new DinaryMap({ el, naverKey, labelZoom: 15, onPin, onGhost, onView });
 *   map.setPins([{key, lat, lng, color, filled, name, rating}], activeKey);
 *   map.setGhost({ lat, lng, name });   // 기록 없는 자리 (점선 핀)
 */
(function () {
  "use strict";

  var CARTO = "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png";
  var ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>';
  var NAVER_SRC = "https://oapi.map.naver.com/openapi/v3/maps.js?ncpKeyId=";

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }

  function teardrop(o) {
    var size = o.active ? 32 : 24;
    var dot = o.active ? 10 : 8;
    var bw = o.active ? 2 : 1.5;
    var fill = o.filled ? o.color : "#fbfaf6";
    var stroke = o.filled ? "#fbfaf6" : o.color;
    var core = o.filled ? "#fbfaf6" : o.color;
    return '<div style="width:' + size + "px;height:" + size + "px;box-sizing:border-box;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:" + fill +
      ";border:" + bw + "px solid " + stroke + ';box-shadow:1px -1px 5px rgba(28,26,23,.18);display:flex;align-items:center;justify-content:center">' +
      '<div style="width:' + dot + "px;height:" + dot + "px;border-radius:50%;background:" + core + ';transform:rotate(45deg)"></div></div>';
  }

  function ghostDrop() {
    return '<div style="width:24px;height:24px;box-sizing:border-box;border-radius:50% 50% 50% 0;transform:rotate(-45deg);' +
      'background:rgba(138,131,119,.15);border:1.5px dashed #8a8377"></div>';
  }

  function shadow(active) {
    var w = active ? 12 : 9;
    var h = active ? 4 : 3;
    return '<div style="width:' + w + "px;height:" + h + 'px;border-radius:50%;background:rgba(28,26,23,.16)"></div>';
  }

  /* 이름표 — 지도를 충분히 당겼을 때만 보입니다. */
  function nameplate(o, show) {
    if (!o.name) return "";
    var rating = o.rating
      ? '<span style="font-family:\'JetBrains Mono\',monospace;font-size:10.5px;line-height:1.2;color:#8a8377">' + esc(o.rating) + "</span>"
      : "";
    return '<div data-label style="display:' + (show ? "flex" : "none") +
      ";flex-direction:column;align-items:center;gap:1px;padding:6px 11px 5px;border-radius:13px 13px 13px 3px;" +
      "border:1px solid #d8d3c8;background:#fbfaf6;box-shadow:0 4px 12px rgba(28,26,23,.09);white-space:nowrap" +
      (o.active ? ";border-color:#e0c3b1" : "") + '">' +
      '<span style="font-size:12.5px;font-weight:600;line-height:1.2;color:#1c1a17">' + esc(o.name) + "</span>" +
      rating + "</div>";
  }

  function stack(inner) {
    return '<div style="position:absolute;left:0;bottom:0;transform:translateX(-50%);display:flex;flex-direction:column;' +
      'align-items:center;gap:5px;cursor:pointer;pointer-events:auto">' + inner + "</div>";
  }

  function pinHtml(o, show) {
    return stack(nameplate(o, show) + teardrop(o) + shadow(o.active));
  }

  /* 기록 없는 자리 — 이름표가 곧 "기록 추가" 단추입니다. */
  function ghostPinHtml(o) {
    var plate = '<div style="display:flex;flex-direction:column;align-items:center;gap:1px;padding:7px 12px 6px;' +
      "border-radius:13px 13px 13px 3px;border:1px solid #e0c3b1;background:#fbfaf6;box-shadow:0 6px 16px rgba(28,26,23,.12);white-space:nowrap\">" +
      '<span style="font-size:12.5px;font-weight:600;line-height:1.2;color:#1c1a17">' + esc(o.name) + "</span>" +
      '<span style="font-size:11px;line-height:1.3;color:#b4552d">+ 여기에 기록 추가</span></div>';
    return stack(plate + ghostDrop() + shadow(false));
  }

  function waitFor(test, cb) {
    if (test()) { cb(); return null; }
    var t = setInterval(function () { if (test()) { clearInterval(t); cb(); } }, 60);
    return t;
  }

  function loadNaver(key, onload, onerror) {
    var found = document.querySelector("script[data-dinary-naver]");
    if (found) {
      if (window.naver && window.naver.maps) { onload(); return; }
      found.addEventListener("load", onload);
      found.addEventListener("error", onerror);
      return;
    }
    var el = document.createElement("script");
    el.src = NAVER_SRC + encodeURIComponent(key);
    el.async = true;
    el.setAttribute("data-dinary-naver", "1");
    el.addEventListener("load", onload);
    el.addEventListener("error", onerror);
    document.head.appendChild(el);
  }

  function DinaryMap(opts) {
    this.opts = opts || {};
    this.labelZoom = this.opts.labelZoom == null ? 15 : this.opts.labelZoom;
    this.center = this.opts.center || [37.5665, 126.978];
    this.zoom = this.opts.zoom == null ? 12 : this.opts.zoom;
    this.backend = this.opts.naverKey ? "naver" : "tile";
    this.ready = false;
    this.pins = new Map();
    this.ghost = null;
    this._dead = false;
    this._boot();
  }

  DinaryMap.prototype._boot = function () {
    var self = this;
    var start = function () { if (!self._dead) self._create(); };

    if (this.backend === "naver") {
      loadNaver(this.opts.naverKey,
        function () {
          self._wait = waitFor(function () { return window.naver && window.naver.maps; }, start);
        },
        function () {
          // 키가 막혀 있으면 타일 지도로 물러납니다.
          self.backend = "tile";
          self._wait = waitFor(function () { return window.L; }, start);
        });
      return;
    }
    this._wait = waitFor(function () { return window.L; }, start);
  };

  DinaryMap.prototype._create = function () {
    var el = typeof this.opts.el === "function" ? this.opts.el() : this.opts.el;
    if (!el) {
      var self = this;
      this._retry = setTimeout(function () { if (!self._dead) self._create(); }, 80);
      return;
    }
    if (this.backend === "naver") this._createNaver(el);
    else this._createTile(el);

    this.ready = true;
    if (this.opts.onReady) this.opts.onReady(this);
  };

  DinaryMap.prototype._createNaver = function (el) {
    var nm = window.naver.maps;
    var self = this;
    this.map = new nm.Map(el, {
      center: new nm.LatLng(this.center[0], this.center[1]),
      zoom: this.zoom,
      zoomControl: false,
      mapDataControl: false,
      scaleControl: false,
      logoControlOptions: { position: nm.Position.BOTTOM_RIGHT },
    });
    nm.Event.addListener(this.map, "zoom_changed", function () { self._syncLabels(); });
    nm.Event.addListener(this.map, "idle", function () { if (self.opts.onView) self.opts.onView(); });
  };

  DinaryMap.prototype._createTile = function (el) {
    var L = window.L;
    var self = this;
    this.map = L.map(el, {
      zoomControl: false,
      attributionControl: !!this.opts.attribution,
      keyboard: false,
    }).setView(this.center, this.zoom);
    L.tileLayer(CARTO, {
      maxZoom: 19,
      subdomains: "abcd",
      className: "paper-tiles",
      attribution: ATTR,
    }).addTo(this.map);
    if (this.opts.zoomControl) L.control.zoom({ position: this.opts.zoomControl }).addTo(this.map);
    this.map.on("zoomend", function () { self._syncLabels(); });
    this.map.on("moveend", function () { if (self.opts.onView) self.opts.onView(); });
  };

  DinaryMap.prototype.showLabels = function () {
    return this.getZoom() >= this.labelZoom;
  };

  DinaryMap.prototype.getZoom = function () {
    if (!this.map) return this.zoom;
    return this.map.getZoom();
  };

  /* 이름표만 껐다 켭니다 — 핀을 다시 만들지 않아 깜빡이지 않습니다. */
  DinaryMap.prototype._syncLabels = function () {
    var show = this.showLabels();
    if (show === this._shown) return;
    this._shown = show;
    this.pins.forEach(function (entry) {
      var host = entry.marker.getElement && entry.marker.getElement();
      var label = host && host.querySelector("[data-label]");
      if (label) label.style.display = show ? "flex" : "none";
    });
    if (this.opts.onLabels) this.opts.onLabels(show);
  };

  DinaryMap.prototype._makeMarker = function (p, html) {
    var self = this;
    if (this.backend === "naver") {
      var nm = window.naver.maps;
      var m = new nm.Marker({
        position: new nm.LatLng(p.lat, p.lng),
        map: this.map,
        icon: { content: html, size: new nm.Size(0, 0), anchor: new nm.Point(0, 0) },
        zIndex: p.active ? 1000 : 100,
      });
      nm.Event.addListener(m, "click", function () { if (self.opts.onPin) self.opts.onPin(p.key); });
      return m;
    }
    var L = window.L;
    var lm = L.marker([p.lat, p.lng], {
      icon: L.divIcon({ className: "restaurant-map-pin", iconSize: [0, 0], iconAnchor: [0, 0], html: html }),
      zIndexOffset: p.active ? 1000 : 0,
    }).addTo(this.map);
    lm.on("click", function () { if (self.opts.onPin) self.opts.onPin(p.key); });
    return lm;
  };

  DinaryMap.prototype._setIcon = function (marker, html, active) {
    if (this.backend === "naver") {
      var nm = window.naver.maps;
      marker.setIcon({ content: html, size: new nm.Size(0, 0), anchor: new nm.Point(0, 0) });
      marker.setZIndex(active ? 1000 : 100);
      return;
    }
    var L = window.L;
    marker.setIcon(L.divIcon({ className: "restaurant-map-pin", iconSize: [0, 0], iconAnchor: [0, 0], html: html }));
    marker.setZIndexOffset(active ? 1000 : 0);
  };

  DinaryMap.prototype._drop = function (marker) {
    if (this.backend === "naver") marker.setMap(null);
    else marker.remove();
  };

  DinaryMap.prototype.setPins = function (list, activeKey) {
    if (!this.ready) { this._pending = { list: list, activeKey: activeKey }; return; }
    var self = this;
    var show = this.showLabels();
    this._shown = show;
    var next = new Set((list || []).map(function (p) { return p.key; }));

    this.pins.forEach(function (entry, key) {
      if (!next.has(key)) { self._drop(entry.marker); self.pins.delete(key); }
    });

    (list || []).forEach(function (raw) {
      var p = Object.assign({}, raw, { active: raw.key === activeKey });
      var sig = [p.active, p.filled, p.color, p.name, p.rating, p.lat, p.lng].join("|");
      var entry = self.pins.get(p.key);
      var html = pinHtml(p, show);
      if (!entry) {
        self.pins.set(p.key, { marker: self._makeMarker(p, html), sig: sig });
        return;
      }
      if (entry.sig !== sig) {
        self._setIcon(entry.marker, html, p.active);
        entry.sig = sig;
      }
    });
  };

  DinaryMap.prototype.setGhost = function (g) {
    if (!this.ready) { this._pendingGhost = g; return; }
    var self = this;
    if (this._ghostMarker) { this._drop(this._ghostMarker); this._ghostMarker = null; }
    if (!g) return;

    var html = ghostPinHtml(g);
    if (this.backend === "naver") {
      var nm = window.naver.maps;
      var m = new nm.Marker({
        position: new nm.LatLng(g.lat, g.lng),
        map: this.map,
        icon: { content: html, size: new nm.Size(0, 0), anchor: new nm.Point(0, 0) },
        zIndex: 1200,
      });
      nm.Event.addListener(m, "click", function () { if (self.opts.onGhost) self.opts.onGhost(g); });
      this._ghostMarker = m;
      return;
    }
    var L = window.L;
    var lm = L.marker([g.lat, g.lng], {
      icon: L.divIcon({ className: "restaurant-map-pin", iconSize: [0, 0], iconAnchor: [0, 0], html: html }),
      zIndexOffset: 1200,
    }).addTo(this.map);
    lm.on("click", function () { if (self.opts.onGhost) self.opts.onGhost(g); });
    this._ghostMarker = lm;
  };

  DinaryMap.prototype.flyTo = function (lat, lng, zoom) {
    if (!this.map) return;
    if (this.backend === "naver") {
      var nm = window.naver.maps;
      if (zoom != null) this.map.setZoom(zoom, true);
      this.map.panTo(new nm.LatLng(lat, lng));
      return;
    }
    this.map.flyTo([lat, lng], zoom == null ? this.map.getZoom() : zoom, { duration: 0.7 });
  };

  DinaryMap.prototype.fitPins = function (pts, pad) {
    if (!this.map || !pts || !pts.length) return;
    pad = pad || {};
    if (pts.length === 1) {
      this.setView(pts[0][0], pts[0][1], Math.max(this.getZoom(), 15));
      return;
    }
    if (this.backend === "naver") {
      var nm = window.naver.maps;
      var b = new nm.LatLngBounds(new nm.LatLng(pts[0][0], pts[0][1]), new nm.LatLng(pts[0][0], pts[0][1]));
      pts.forEach(function (p) { b.extend(new nm.LatLng(p[0], p[1])); });
      try { this.map.fitBounds(b, pad); } catch (e) { this.map.fitBounds(b); }
      return;
    }
    var L = window.L;
    this.map.fitBounds(L.latLngBounds(pts), {
      paddingTopLeft: [pad.left || 30, pad.top || 30],
      paddingBottomRight: [pad.right || 30, pad.bottom || 30],
      maxZoom: pad.maxZoom || 15,
    });
  };

  DinaryMap.prototype.setView = function (lat, lng, zoom) {
    if (!this.map) return;
    if (this.backend === "naver") {
      var nm = window.naver.maps;
      this.map.setCenter(new nm.LatLng(lat, lng));
      if (zoom != null) this.map.setZoom(zoom);
      return;
    }
    this.map.setView([lat, lng], zoom == null ? this.map.getZoom() : zoom);
  };

  DinaryMap.prototype.getBounds = function () {
    if (!this.map) return null;
    if (this.backend === "naver") {
      var b = this.map.getBounds();
      var sw = b.getSW ? b.getSW() : b.getMin();
      var ne = b.getNE ? b.getNE() : b.getMax();
      return { s: sw.lat(), w: sw.lng(), n: ne.lat(), e: ne.lng() };
    }
    var lb = this.map.getBounds();
    return { s: lb.getSouth(), w: lb.getWest(), n: lb.getNorth(), e: lb.getEast() };
  };

  DinaryMap.prototype.resize = function () {
    if (!this.map) return;
    if (this.backend === "naver") window.naver.maps.Event.trigger(this.map, "resize");
    else this.map.invalidateSize();
  };

  DinaryMap.prototype.destroy = function () {
    this._dead = true;
    clearInterval(this._wait);
    clearTimeout(this._retry);
    if (!this.map) return;
    if (this.backend === "naver") this.map.destroy();
    else this.map.remove();
    this.map = null;
  };

  window.DinaryMap = DinaryMap;
})();
