# Handoff: DINARY — Next.js 웹앱 → Expo 네이티브 앱

## 개요

DINARY(한국 음식점·카페 기록 앱)를 Next.js 웹앱에서 **Expo(React Native) 네이티브 앱**으로 옮깁니다. 웹뷰 래퍼가 아니라 진짜 네이티브 앱입니다.

원본 저장소: `taehyeon-k/restaurant-log` (branch `main`)
원본 모바일 UI: `src/app/_components/mobile/*`

확정된 방향:
- **내비게이션 구조 = 1a** — 하단 탭 4개 + 가운데 솟은 카메라 버튼(전체화면 모달)
- **비주얼 방향 = 1d** — 「종이 위의 네이티브」. DINARY 종이 팔레트와 세리프를 유지하되, 시트·제스처·햅틱은 네이티브 규범을 따릅니다.

대상 플랫폼: **iOS · Android 동등**
백엔드: **Supabase 유지** (스키마 변경 없음)

---

## 이 번들의 디자인 파일에 대하여

이 폴더의 `.dc.html` 파일들은 **HTML로 만든 디자인 참조물**입니다. 의도한 모양과 동작을 보여주는 시제품이지, 그대로 가져다 쓸 프로덕션 코드가 아닙니다.

할 일은 이 HTML 디자인을 **Expo / React Native 환경에서 다시 만드는 것**입니다. HTML을 WebView에 넣는 것은 이 작업의 목적에 정면으로 어긋납니다.

## 완성도

**하이파이(hifi)** 입니다. 색·타이포·간격·radius가 모두 확정값이며, 대부분 기존 저장소의 실제 값에서 가져왔습니다. 픽셀 단위로 맞춰 주세요. 값이 애매하면 원본 저장소의 해당 컴포넌트를 먼저 확인하십시오 — 디자인은 그 코드에서 출발했습니다.

---

## 1. 기술 스택 결정

| 영역 | 선택 | 이유 / 주의 |
|---|---|---|
| 라우팅 | `expo-router` (file-based) | `MobileShell.tsx` 의 화면 상태기를 라우트로 푼다 |
| 스타일 | **NativeWind v4** | 기존 Tailwind `className` 문자열 대부분이 그대로 살아난다 |
| 지도 | `@mj-studio/react-native-naver-map` | config plugin 필요. **Expo Go 불가** |
| 카메라 | `expo-camera` (`CameraView`) | `getUserMedia` 대체 |
| 이미지 처리 | `expo-image-manipulator` | 900px 리사이즈 + JPEG 0.72 |
| 갤러리 | `expo-image-picker` | `<input type="file" capture>` 대체 |
| 위치 | `expo-location` | 전경: `getCurrentPositionAsync` |
| 지오펜스 | `expo-location` + `expo-task-manager` | 위시 근처 알림 |
| 알림 | `expo-notifications` | 로컬 + Expo push |
| 로컬 저장 | `@react-native-async-storage/async-storage` | 세션 + 간단한 값 |
| 오프라인 큐 | `expo-sqlite` | 미전송 기록·사진 |
| 시트 | `@gorhom/bottom-sheet` v5 | 지도 목록 시트 |
| SVG | `react-native-svg` | `clip-path` 도형 전부 |
| 햅틱 | `expo-haptics` | 칩·마커·셔터 |
| 폰트 | `expo-font` + `@expo-google-fonts/*` | Gowun Batang, Noto Sans KR, JetBrains Mono |
| 안전영역 | `react-native-safe-area-context` | `env(safe-area-inset-*)` 대체 |

### 첫날에 반드시 할 것

네이버 지도 SDK와 백그라운드 위치는 **Expo Go에서 돌지 않습니다.**

```bash
npx expo install expo-dev-client
eas build --profile development --platform all
```

개발 빌드부터 세우지 않으면 지도 붙이는 단계에서 며칠을 잃습니다.

---

## 2. 라우트 구조 (1a)

```
app/
  _layout.tsx                  Stack  (root, headerShown:false)
  (tabs)/
    _layout.tsx                Tabs ×4 + 가운데 카메라 버튼
    calendar.tsx               캘린더
    index.tsx                  지도        ← 기본 탭
    wish.tsx                   위시리스트
    account.tsx                내계정
  capture.tsx                  촬영 흐름   presentation: 'fullScreenModal'
  place/[key].tsx              장소 상세
  record/[id].tsx              기록 상세
  record/[id]/edit.tsx         기록 편집
  wish/new.tsx                 위시 추가   presentation: 'modal'
  drafts.tsx                   보관함
  day/[date].tsx               하루 상세
  login.tsx
  welcome.tsx
```

### 탭 설정 — 가운데 카메라

`(tabs)/_layout.tsx` 에서 5칸 그리드를 흉내내지 말고, **탭 4개 + 절대 위치 버튼**으로 만드세요. 가운데 버튼은 탭이 아니라 `router.push('/capture')` 를 호출하는 일반 버튼입니다. 탭 상태를 건드리지 않아야 합니다.

```
탭바 높이: 74 + insets.bottom
배경: #fbfaf6, 위쪽 테두리 1px #e2ddd2
그림자: iOS shadowColor #1c1a17 / opacity .06 / radius 14 / offset {0,-2}
        Android elevation 8
카메라 버튼: 62×62, borderRadius 31, 배경 #b4552d,
             테두리 3px #fbfaf6, 탭바 상단 기준 top: -22
             그림자 rgba(180,85,45,.34) radius 20 offset {0,8}
라벨: JetBrains Mono 9.5px, 활성 #b4552d / 비활성 #a29a8c
아이콘: 21×21 stroke 1.6 currentColor
```

아이콘 SVG path는 `src/app/_components/mobile/TabBar.tsx` 에 그대로 있습니다. `react-native-svg` 로 옮기세요.

> **Android 주의** — 솟은 가운데 버튼은 Material 규범이 아닙니다. Android에서 버튼이 탭바 밖으로 넘칠 때 터치가 씹히지 않도록 탭바 컨테이너에 `overflow: visible` 과 충분한 `paddingTop` 을 주세요.

---

## 3. 디자인 토큰

`src/app/globals.css` 의 `@theme` 을 `tailwind.config.js` 로 옮깁니다.

```js
colors: {
  paper:      '#f6f3ec',   // 화면 배경
  card:       '#fbfaf6',   // 카드·시트·입력
  ink:        '#1c1a17',   // 본문
  brick:      '#b4552d',   // 강조 (인증·활성·마커)
  'brick-soft':'#f7ece5',
  line:       '#d8d3c8',
  'line-soft':'#e2ddd2',
  muted:      '#6b665e',
  faint:      '#8a8377',
  map:        '#e7e3d8',
  'map-grid': '#dcd7c9',
  'map-road': '#f1ede2',
  'map-park': '#dfe4d6',
  kakao:      '#fee500',   // 카카오 브랜드 고정색
}
```

카테고리 핀 색(`src/lib/types.ts` `CATEGORY_COLORS`)은 **그대로 복사**합니다.

```
한식 #b4552d · 중식 #9a4a52 · 일식 #5f7a8a · 양식 #7a6a9a
아시안 #6f8455 · 분식 #c07a2e · 커피 #7a5c42 · 디저트 #b06a86
베이커리 #a8853f · 차 #4f7a6a · 없음 #8a8377
```

### 타이포

| 역할 | 서체 | 크기 / 굵기 | 자간 |
|---|---|---|---|
| 화면 제목·가게 이름 | Gowun Batang | 16–27px / 700 | — |
| 본문·라벨 | Noto Sans KR | 11.5–15px / 400·500·700 | — |
| eyebrow·거리·수치 | JetBrains Mono | 9.5–11px | 0.1–0.22em |

> Gowun Batang은 `@expo-google-fonts/gowun-batang` 에 있습니다. 한글 웨이트가 무겁습니다 — `useFonts` 로딩 중 `SplashScreen.preventAutoHideAsync()` 로 깜빡임을 막으세요.

### 간격·형태

```
radius:  카드/후보행 20 · 시트 26(위쪽만) · 입력·칩 16/18 · 사진 22 · 원형 50%
         큰 카드 30 · 썸네일 16–18
입력 높이: 48 (min-h-12)
터치 타겟: 최소 44×44
가로 여백: 화면 16 또는 20 (촬영 흐름은 20, 지도 오버레이는 16)
그림자(iOS): shadowColor '#1c1a17'
  카드    opacity .08  radius 14  offset {0,4}
  시트    opacity .13  radius 30  offset {0,-10}
  큰 카드 opacity .09  radius 32  offset {0,12}
Android는 elevation 2 / 12 / 10 으로 근사
```

---

## 4. 화면 명세

### 4.1 지도 (`(tabs)/index.tsx`) — 디자인 참조 `1d`

**목적** — 내 기록과 위시를 지도 위에서 보고, 아래 시트에서 목록으로 훑습니다.

**레이아웃 (위→아래)**

1. **지도** — 화면 전체를 채움. `<NaverMapView>` 가 최하단 레이어.
2. **검색 행** — `top: insets.top + 8`, 좌우 16.
   - 검색 필드: `flex:1`, 높이 46, radius 23, 배경 `#fbfaf6`, 테두리 1px `#d8d3c8`, 좌우 패딩 15, 그림자(카드). 돋보기 15×15 stroke `#8a8377` 1.6. placeholder `음식점이나 지역 찾기` 13.5px `#b3ada1`.
   - 라벨첩 버튼: 44×44 원, 같은 배경·테두리·그림자. 안에 24각 버스트 18×18 `#b4552d`.
3. **필터 칩** — 검색 행 아래 12. 컨테이너 radius 18, 테두리 1px `#d8d3c8`, 배경 `rgba(251,250,246,.95)`, 패딩 3. 칩 높이 30, radius 15, 좌우 12, 11.5px. 활성 `#b4552d` / `#fbfaf6`, 비활성 투명 / `#6b665e`.
4. **현위치 버튼** — 우측 16, 칩 아래. 44×44 원, 카드 배경·테두리·그림자.
5. **바텀시트** — `@gorhom/bottom-sheet`, `snapPoints: ['12%', '46%', '88%']`, 기본 중간. 배경 `#fbfaf6`, 위쪽 radius 26, 그림자(시트). 핸들 38×4 radius 2 `#ded8cb`.
   - 헤더: `이 지역의 기록` Gowun Batang 19/700 + 개수 JetBrains Mono 11 `#8a8377` + 우측 `최근순 ▾` 11.5 `#6b665e`. 패딩 20/6/12.
   - 목록: `BottomSheetFlatList`, 항목 사이 10, 좌우 16.
   - 카드: radius 20, 테두리 1px `#e2ddd2`, 배경 `#f6f3ec`, 패딩 12, 썸네일 64×64 radius 16 + 본문 gap 12.
     - 이름 Gowun Batang 16/700 (인증 뱃지 14×14 버스트 `#b4552d` 를 옆에)
     - 메타 `한식 · 중구 · 26.08.14` 11.5 `#8a8377`, 위 여백 4
     - 별점 ★ 12.5 `#b4552d` letterSpacing 1 + 가격 JetBrains Mono 10 `#8a8377`, 위 여백 6
6. **탭바** — §2 참조. 시트는 탭바 위(`bottom: 74 + insets.bottom`)에서 멈춥니다.

**지도 톤 — 중요**

웹은 `.naver-map-tone` CSS 필터(`saturate(.55) sepia(.22) hue-rotate(-8deg) …`)로 종이색을 냈습니다. **네이티브 지도에는 필터를 걸 수 없습니다.** 두 가지 길:

1. (권장) NCP 콘솔에 종이톤 커스텀 지도 스타일을 등록하고 style id 로 불러옵니다. 유일하게 깨끗한 방법입니다.
2. 임시로 지도 위에 `pointerEvents="none"` 인 `rgba(246,243,236,0.18)` 오버레이를 덮습니다. 마커까지 흐려지므로 정식 해법은 아닙니다.

**마커** — `src/app/_components/mobile/mapPin.ts` 가 HTML 문자열로 핀을 만듭니다. `react-native-svg` 로 다시 그리세요. 핀 24×24, `borderRadius: 50% 50% 50% 0` + `rotate(-45deg)` 는 RN에서 재현이 어려우므로 **SVG path 한 장**으로 그리는 편이 낫습니다. 색은 `pinColor(category)`. 위시 마커는 `BookmarkIcon` 모양(ui.tsx의 path 그대로).

**이름표** — `.restaurant-map-tooltip` 은 `<NaverMapMarkerOverlay>` 의 커스텀 children 으로: 배경 `#fbfaf6`, 테두리 1px `#d8d3c8`, radius `14 14 14 3`, 패딩 `7 12 6`, 13px, 그림자(카드).

---

### 4.2 촬영 흐름 (`capture.tsx`) — 디자인 참조 `1f`

원본: `src/app/_components/mobile/CaptureFlow.tsx`. 웹의 3단계 앞에 **권한 준비** 한 장이 붙고, 끝에 **오프라인 큐** 상태가 붙습니다.

`presentation: 'fullScreenModal'`, `animation: 'slide_from_bottom'`, `gestureEnabled: false`.

#### 단계 01 — 권한 준비 (새 화면)

OS 권한 다이얼로그를 띄우기 **전에** 왜 필요한지 DINARY 말투로 설명합니다. 웹에는 없던 화면이고, 권한 거부율을 크게 낮춥니다.

```
배경 #f6f3ec
닫기 ✕  좌 20, top: insets.top + 8, 44×44, 17px #1c1a17

제목  좌우 28, top: insets.top + ~96
      「그 자리에 있었다는 것,\n사진과 위치로 남깁니다」
      Gowun Batang 27/700, lineHeight 1.4
설명  위 여백 14, 13px #6b665e, lineHeight 1.85
      「DINARY 의 인증은 가게 앞에서 찍은 사진에만 붙습니다. 그래서 두 가지가 필요합니다.」

카드 3장 (좌우 24, 사이 12, radius 22, 패딩 18, gap 14)
  ① 카메라 — 테두리 1px #e2ddd2, 배경 #fbfaf6
     아이콘칸 42×42 radius 14 배경 #f7ece5, 카메라 아이콘 21 stroke #b4552d
     제목 14.5/700 「카메라」
     본문 12 #6b665e lh 1.7
     「인증 사진을 찍는 데에만 씁니다. 갤러리에서 고른 사진에는 인증이 붙지 않습니다.」
  ② 위치 — 같은 형식, 핀 아이콘
     「사진 찍는 순간 한 번만 읽어 50m 안의 가게를 찾습니다. 좌표는 기록에 남기지 않습니다.」
  ③ 알림 — 테두리 1px dashed #d8d3c8, 배경 투명, 아이콘칸 #efeade, 종 아이콘 #8a8377
     제목 #4a453d, 본문 #8a8377
     「담아둔 곳 근처에 왔을 때 알려 드립니다. 첫 위시를 저장하는 순간 여쭙습니다.」

하단 (좌우 24, bottom: insets.bottom + 10)
  주 버튼  radius 20, 배경 #1c1a17, 글자 #fbfaf6 15/500, 패딩 18, 중앙정렬
           「허용하고 촬영 시작」
  보조     위 여백 8, 패딩 14, 13px #8a8377, 중앙정렬
           「인증 없이 기록만 남길게요」
```

동작:
- 주 버튼 → `Camera.requestCameraPermissionsAsync()` → `Location.requestForegroundPermissionsAsync()` → 단계 02.
- 알림 권한은 **여기서 요청하지 않습니다**. 첫 위시 저장 때로 미룹니다.
- 이미 두 권한이 모두 허용돼 있으면 이 화면을 건너뛰고 바로 02로 갑니다.
- 거부 상태로 다시 들어오면 주 버튼 문구를 `설정에서 허용하기` 로 바꾸고 `Linking.openSettings()`.

#### 단계 02 — 촬영

```
배경 #171614 (전체화면)
미리보기 CameraView — 화면 전체. 웹의 352px 프레임은 버립니다.
                     네이티브는 전체화면이 규범입니다.

닫기 ✕   좌 16, top: insets.top + 8, 44×44 원 rgba(251,250,246,.14), 16px #fbfaf6
플래시   우 16, 같은 크기·배경, 번개 아이콘 19 stroke #fbfaf6 1.6  (off/on/auto 순환)

제목 블록 top: insets.top + 14, 가운데 정렬, gap 7
  「지금 여기」 Gowun Batang 18/700 #fbfaf6
  상태 pill  radius 14, 배경 rgba(251,250,246,.12), 패딩 5/12, 11px rgba(251,250,246,.8)
  위시 pill  (verifyWishId 있을 때만) 배경 rgba(180,85,45,.34), 북마크 11 + 11px #fbfaf6
             「{위시이름} · 담아둔 곳」

배율 버튼  bottom: insets.bottom + 214, 가운데, gap 8
  .5× / 1× / 2×  — 44×44(활성 50×50) 원, 비활성 rgba(251,250,246,.14),
                   활성 rgba(251,250,246,.26), JetBrains Mono 11/12.5
  ※ 웹의 슬라이더 + CSS 크롭(CSS_ZOOM_RANGE, grabFrame 의 crop 계산)은 삭제합니다.
    네이티브는 렌즈를 실제로 바꿉니다.

하단 행  bottom: insets.bottom + 104, 가운데, gap 34
  갤러리 썸네일 46×46 radius 12 — expo-media-library 최근 사진 1장
  셔터 78×78 원, 테두리 3px rgba(251,250,246,.85), 안쪽 62 원 #fbfaf6
  전환 46×46 원 rgba(251,250,246,.1), 회전 아이콘 20 stroke rgba(251,250,246,.65)

주석  bottom: insets.bottom + 56, 가운데, 11.5px rgba(251,250,246,.45)
      「갤러리에서 고른 사진은 인증되지 않아요」
```

촬영 처리:
```ts
const photo = await cameraRef.current.takePictureAsync({ quality: 0.9, skipProcessing: true });
const out = await ImageManipulator.manipulateAsync(
  photo.uri,
  [{ resize: { width: 900 } }],            // 긴 변 900 — 웹과 동일
  { compress: 0.72, format: SaveFormat.JPEG }
);
// 동시에 위치 1회 읽기
Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
```

**삭제되는 에러 분기** — 웹 `camMessage()` 의 `TimeoutError`(브라우저에서 카메라 안 열림)와 `NotSupported` 는 네이티브에 존재하지 않습니다. 남는 건 권한 거부(→ 설정 열기)와 카메라 없음뿐입니다.

#### 단계 03 — 여기 어디예요?

```
배경 #f6f3ec, 좌우 20

상단 (top: insets.top + 8)
  썸네일 74×74 radius 18 (찍은 사진) + gap 14 + 본문
    제목 「여기 어디예요?」 Gowun Batang 20/700 lh 1.35
    부제 11.5 #6b665e lh 1.55
         위치 있음 → 「지금 위치에서 가까운 곳입니다 (정확도 {acc}m)」
         없음     → geoErr 문구 또는 「위치를 읽는 중입니다…」
  종류 세그먼트 (위 여백 12) radius 18, 테두리 1px #d8d3c8, 배경 #fbfaf6, 패딩 3
    맛집 / 카페 — 각 flex 1, 높이 30, radius 15, 11.5px
    활성 #b4552d / #fbfaf6, 비활성 투명 / #6b665e

후보 목록 (top 206 ~ 하단 안내 위, FlatList, 사이 9)
  기본 후보   radius 20, 테두리 1px #ded8cb, 배경 #fbfaf6, 패딩 13/15, minHeight 62
  강조 후보   테두리 1.5px #b4552d, 배경 #f9f0e9, 그림자 rgba(180,85,45,.1) r14 y4
              (거리 1위이거나 위시와 짝지어진 후보)
  먼 후보     배경 투명, opacity .5, 비활성화
  거리 배지   34×34 원, JetBrains Mono 9.5
              강조 #f7ece5/#b4552d · 기본 #f1ede4/#6b665e
  위시 머리말 북마크 12 fill #b4552d + JetBrains Mono 10.5 #b4552d
              「위시리스트에 담아둔 식당」, 아래 여백 5
  이름       Gowun Batang 16/700, 한 줄 자름
  메타       11.5 #8a8377, 위 여백 3 — 「내 기록」 또는 카테고리 + 주소
  먼 경우    10.5 #a29a8c 「너무 멀어 고를 수 없습니다」
  마지막 행   minHeight 48, radius 20, 테두리 1px dashed #d8d3c8, 12.5 #6b665e
              「여기 없어요 · 직접 찾기」 → 가게 찾기 화면

오프라인 배너 (오프라인일 때만, 하단 안내 위 88)
  radius 18, 테두리 1px #e0c3b1, 배경 #f9f0e9, 패딩 13/15
  점 8×8 #b4552d + 11.5 #6b665e
  「지금 오프라인입니다. 인증은 그대로 붙고, 사진은 연결되면 올라갑니다.」

개인정보 안내 (bottom: insets.bottom + 10)
  radius 18, 테두리 1px #e4dfd3, 배경 #fbfaf6, 패딩 13/15
  핀 15 #b4552d + 11.5 #6b665e
  「읽은 좌표는 가까운 가게를 찾는 데에만 쓰고, 기록에는 남기지 않습니다.」
```

**로직은 웹 그대로 가져옵니다.** `CaptureFlow.tsx` 의 `metersBetween`, `mine`, `candidates`, `pickCandidates`, `pickList`, `noneNear`, `searchHits` 는 DOM을 모르는 순수 계산입니다. 상수도 동일:

```
PICK_MAX_M = 50     인증 가능 최대 거리
WISH_NEAR_M = 50    후보를 위로 올리는 거리 (lib/types.ts)
WISH_AUTO_M = 100   후보를 묻지 않고 자동 확정하는 거리
내 기록 후보: 800m 이내 · 최대 4곳
전체 후보: 최대 8곳
```

#### 단계 03a — 가게 찾기

`searchOpen` 분기 그대로. 헤더(뒤로 ← + 「가게 찾기」 Gowun Batang 18/700 + 종류 세그먼트) + 입력(높이 48, radius 16, 테두리 `#ded8cb`, 포커스 `#b4552d`) + 안내문 + 결과 목록. 250ms 디바운스 후 2글자 이상이면 `searchFoodPlaces` 호출.

50m 밖 결과를 누르면 인증 없이 기록으로 넘깁니다(`onUnverified(name, kind)`).

#### 단계 04 — 인증 완료

```
배경 #f6f3ec

카드 (좌우 20, top: insets.top + 12)
  radius 30, 배경 #fbfaf6, 패딩 14/14/20, 그림자(큰 카드)
  사진 높이 296, radius 22
    시각 배지  좌상 14/14, radius 14, 배경 rgba(28,26,23,.55),
               JetBrains Mono 9.5 자간 .1em #fbfaf6 — 「19:42」
    인증 마크  우하 16/16, 52×52 — VerifiedMark (24각 버스트 #b4552d + 체크)
  제목 (위 여백 18, 가운데) 「방문이 인증되었습니다」 Gowun Batang 22/700
  부제 (위 7) 12 #6b665e — 「{가게이름} · 2026.09.18 19:42」
  WISH MET 배지 (있을 때, 위 12) radius 14, 테두리 1px #e0c3b1, 배경 #f9f0e9,
    패딩 7/12, 북마크 12 + 11px #b4552d
    「담아둔 지 {days}일 만에 다녀왔습니다」

업로드 상태 (좌우 20, 카드 아래)
  radius 18, 테두리 1px #e4dfd3, 배경 #fbfaf6, 패딩 14/16, gap 11
  스피너 30×30 (테두리 2px #e2ddd2, 위쪽만 #b4552d, 회전)
  「사진 올리는 중 · 1 / 1」 12.5/500
  「앱을 닫아도 이어서 올라갑니다.」 11 #8a8377

하단 (좌우 20, bottom: insets.bottom + 10)
  주 버튼  radius 20, 배경 #1c1a17, #fbfaf6 15/500, 패딩 17 — 「이어서 기록 쓰기」
  보조     위 8, 패딩 14, 13 #8a8377 — 「나중에 쓸게요」
```

---

## 5. 상태 · 데이터

### 전역

`MobileShell.tsx` 가 들고 있던 것을 라우트 위로 올립니다. **TanStack Query** 를 권합니다.

```
rows: Restaurant[]        restaurants 테이블 (내 기록)
wishes: Wish[]            wishes 테이블
session                   Supabase auth
netInfo.isConnected       @react-native-community/netinfo
```

### 촬영 흐름 로컬 상태

```
step: 'permission' | 'shoot' | 'pick' | 'search' | 'done'
shot: { uri: string } | null
shotAt: Date | null
geo: { lat, lng, acc } | null
geoErr: string | null
facing: 'back' | 'front'
zoom: 0 | 1 | 2                 (.5× / 1× / 2×)
picked: Candidate | null
pickKind: 'restaurant' | 'cafe'
autoMatched: boolean
saving / error
```

웹의 `session`·`cam`·`zoomCaps`·`trackRef`·`pinchRef`·`liveRef`·`timerRef` 는 전부 삭제합니다 — `getUserMedia` 재시도 관리용이라 네이티브에 대응물이 없습니다.

### Supabase

```ts
createClient(url, anonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,   // ← 필수
  },
})
```

`AppState` 가 active일 때 `supabase.auth.startAutoRefresh()`, background일 때 `stopAutoRefresh()` 를 호출하세요.

**저장 스키마는 바뀌지 않습니다.** `commit()` 의 insert 필드를 그대로 씁니다 (`verified`, `acc`, `pending`, `from_wish`, `place_key` 포함). 사진 업로드만 `dataUrlToBlob` 대신 `fetch(uri).then(r => r.arrayBuffer())` 로 바꿉니다.

### 인증 (카카오)

`app/auth/callback/route.ts` 는 앱에서 못 씁니다. `expo-auth-session` + `dinary://auth` 스킴으로 대체하고, Supabase 콘솔의 redirect URL 목록에 스킴을 추가하세요.

---

## 6. 오프라인 큐

오프라인에서도 인증이 끊기지 않아야 합니다. 지하 식당이 흔합니다.

```
1. 촬영 직후 사진을 FileSystem.documentDirectory 에 복사한다.
2. SQLite `pending_records` 에 insert 페이로드 + 로컬 사진 경로를 쓴다.
3. 화면은 즉시 「인증 완료」로 넘어간다 — 네트워크를 기다리지 않는다.
4. 연결되면 큐를 비운다: 사진 업로드 → restaurants insert → 짝 위시 delete
                         → 로컬 파일 삭제.
5. 실패는 지수 백오프로 재시도. 3회 실패하면 보관함에 「올리지 못함」으로 표시.
```

보관함(`DraftsScreen.tsx`)에 이미 `pending` 기록이 모입니다. 같은 자리에 「올리는 중 / 올리지 못함」 상태만 더하세요. 새 화면을 만들 필요가 없습니다.

`AppState` 복귀와 `NetInfo` 연결 이벤트에서 큐 처리를 트리거합니다.

---

## 7. 알림 · 백그라운드 위치

**기능** — 담아둔 위시 50m 안에 들어오면 알림. 누르면 `/capture?verifyWishId=…` 로 바로 카메라가 열립니다.

**iOS** — 상시 위치 권한 대신 **Region Monitoring**(지오펜스)을 쓰세요. 배터리도 심사도 유리합니다. **동시 감시 20개 제한**이 있으므로 좌표 있는 위시 중 가까운 20개만 등록하고, 앱 실행·위치 변화 때 갱신합니다.

**Android** — 백그라운드 위치는 전경 권한과 **분리된 두 번째 요청**이어야 합니다. Play 콘솔에 사용 목적 영상 제출이 필요합니다. 심사 부담이 크면 1차 출시에서는 앱 실행 중에만 확인하고, 백그라운드는 2차로 미루는 것도 합리적입니다.

권한 요청 시점: 첫 위시를 저장하는 순간. 앱 첫 실행이 아닙니다.

---

## 8. 그대로 복사하는 파일

DOM을 모르는 순수 로직입니다. 한 줄도 고치지 마세요.

```
src/lib/types.ts       CATEGORY_COLORS, pinColor, findMatchingWish, wishMetInfo,
                       matchWish, wishKind, coverPhoto, won, shortDate,
                       dottedDate, seoulParts, verifiedTime, verifiedDateTime,
                       CATEGORIES, KEYWORDS, WISH_NEAR_M, WISH_AUTO_M
src/lib/price.ts       feltLevel, PriceRow
src/lib/places.ts      groupPlaces
src/app/_components/mobile/record.ts   photosOf, photoCount
```

`Intl.DateTimeFormat` 의 `timeZone: 'Asia/Seoul'` 은 **Hermes 기본 빌드에서 동작하지 않습니다.** `app.json` 에 `"jsEngine": "hermes"` + `expo-localization` 을 쓰거나, Hermes Intl 이 켜진 빌드인지 확인하세요. 안 되면 `date-fns-tz` 로 대체합니다. 인증 시각 표시가 여기에 걸립니다.

---

## 9. 자산

| 자산 | 위치 | 비고 |
|---|---|---|
| `piggy.png` | `public/piggy.png` | 체감 가격 돼지 5마리. `assets/` 로 옮기고 `@2x`/`@3x` 준비 |
| 파비콘 | `src/app/favicon.ico` | 앱 아이콘은 1024×1024 PNG로 새로 필요 |
| 아이콘 SVG | `mobile/ui.tsx`, `TabBar.tsx` | path 그대로 `react-native-svg` 로 |
| clip-path 도형 | `mobile/ui.tsx` `CLIP`, `globals.css` `.label-badge-*` | polygon 좌표를 SVG `<Polygon points>` 로 (0–100 좌표계 유지) |

`.label-badge-gold` 같은 비대칭 `border-radius` (`42% 58% 45% 55% / 52% 44% 56% 48%`)는 RN에서 불가능합니다. SVG path로 다시 그려야 합니다.

---

## 10. 작업 순서

지도를 맨 앞에 두지 마세요. 가장 오래 걸리고 가장 자주 막힙니다.

```
① EAS 개발 빌드 + Supabase 인증 + 폰트 로딩
② lib/ 복사 + NativeWind 토큰 설정
③ 탭 뼈대 (1a) + 목록 화면들 — 지도 없이
④ 촬영 흐름 (권한 → 촬영 → 고르기 → 완료)
⑤ 네이버 지도 + 마커
⑥ 오프라인 큐
⑦ 알림 + 지오펜스
⑧ 스토어 제출 (개인정보·이용약관은 웹 링크 재사용)
```

---

## 11. 이 번들의 파일

| 파일 | 내용 |
|---|---|
| `DINARY Native - Directions.dc.html` | 내비게이션 3안·비주얼 2안·촬영 흐름 4화면·이전 지도. **1a + 1d 선택됨** |
| `DINARY Mobile Recreation.dc.html` | 현재 웹 지도 화면의 재현 — 옮기기 전 기준점 |
| `ios-frame.jsx`, `support.js` | 위 HTML을 여는 데 필요한 보조 파일 |
| `screenshots/01-nav-1a.png` | 확정 내비게이션 구조 |
| `screenshots/02-map-1d.png` | 확정 지도 화면 + 주석 |
| `screenshots/03-capture-1f.png` | 촬영 흐름 4화면 + 플랫폼 차이 |
| `screenshots/04-migration-1g.png` | 이전 지도 표 |

브라우저에서 `.dc.html` 을 직접 열면 됩니다. 디자인 값이 애매하면 원본 저장소의 해당 컴포넌트를 먼저 보세요 — 이 디자인은 그 코드에서 출발했습니다.
