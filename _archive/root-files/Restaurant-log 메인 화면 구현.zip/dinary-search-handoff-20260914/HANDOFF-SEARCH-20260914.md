# Handoff: 검색·필터 역할 분리 + 「현 지도에 있는 기록만」

대상 저장소: `taehyeon-k/restaurant-log` (main) · 모바일 화면만 해당

## 문제

상단 검색창과 시트 필터가 둘 다 「찾는 일」처럼 보입니다. 상단은 지도를 옮기는 도구, 시트는 내 기록을 좁히는 도구인데 화면상 구분이 없습니다. 필터 단추가 정렬 줄 끝에 붙어 있어 정렬의 일부처럼도 읽힙니다.

**규칙**: 상단 = 어디로 갈지 (지도 이동). 시트 = 내 기록 좁히기.

---

## 1. 시트 검색칸의 문구

`placeholder` 를 `가게 · 지역 · 메뉴 · 메모` → **`내 기록에서 찾기`** 로 바꿉니다. 상단 검색창과 역할이 갈립니다. 상단 검색창은 건드리지 않습니다.

## 2. 필터 단추를 정렬 줄에서 빼내 검색칸 옆으로

지금 필터 단추는 정렬 줄(`최신순 / 별점순 / 가격순`) 오른쪽 끝에 있습니다. 이것을 **시트 검색칸과 같은 줄, 검색칸 바로 오른쪽**으로 옮깁니다. 정렬 줄에는 정렬만 남습니다.

- 검색칸과 같은 높이(40px), `border-radius:20px`, `flex-shrink:0`
- 아이콘(가로줄 3개가 좁아지는 필터 모양) + 라벨
- 라벨은 **걸린 개수만 숫자로** — 조건이 없으면 `필터`, 2개 걸렸으면 `2`
  (기존 `필터 2` 처럼 단어를 붙이면 좁은 화면에서 검색칸을 밀어냅니다)
- 조건이 걸리면 검은 배경(`#1c1a17` / 글자 `#fbfaf6`), 없으면 종이 배경 + 테두리

```html
<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor"
     stroke-width="1.9" stroke-linecap="round">
  <path d="M4 7h16"></path><path d="M7 12h10"></path><path d="M10 17h4"></path>
</svg>
```

## 3. 걸린 조건을 칩으로 드러냅니다

검색칸 줄 **아래**, 정렬 줄 **위**에 한 줄. 조건이 하나도 없으면 줄 자체가 없습니다.

- 분류 · 상황 키워드 · `재방문` · `인증된 기록` 각각을 칩 하나로
  배경 `#f2e0d5`, 글자 `#a34d27`, `border-radius:15px`, `padding:5px 10px`, 11px
- 칩을 누르면 그 조건만 해제 (`✕` 를 글자 `#c08a6c` 로 뒤에 붙임)
- 맨 끝에 `모두 지우기` (배경 없음, 11px `#8a8377`) — 전체 해제
- 좁은 화면 대비 `overflow-x:auto`, 각 칩 `flex-shrink:0`

**필터 시트를 열지 않아도 무엇이 걸렸는지 보이고, 하나씩 뗄 수 있는 것이 핵심입니다.**

---

## 4. 「현 지도에 있는 기록만」

홈페이지 버전의 "이 지도에서 다시 검색"과 같은 동작을, 모바일에서는 **시트 안**에 둡니다.

### 자리

필터 단추 줄 **바로 아래, 오른쪽 정렬**된 작은 칩. 정렬 줄 위에 옵니다.
지도 위에 띄우지 않습니다 — 거르는 도구는 시트에 모읍니다.

```html
<button style="display:flex; align-items:center; gap:5px; min-height:28px; padding:0 10px;
               border:1px solid #e0c3b1; border-radius:14px; background:#f9f0e9;
               font-size:11px; color:#b4552d; white-space:nowrap">
  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#b4552d"
       stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20.5 12a8.5 8.5 0 1 1-2.6-6.1"></path>
    <path d="M20.5 4.5v4.2h-4.2"></path>
  </svg>
  <span>현 지도에 있는 기록만</span>
</button>
```

### 동작

1. 지도 `moveend` 마다 `mapMoved = true`. **목록은 이 시점에 바뀌지 않습니다** — 지도를 조금 밀 때마다 결과가 흔들리면 쓸 수 없습니다.
2. `mapMoved` 이고 지도 탭이며 촬영 흐름·기록 상세·가게 상세가 열려 있지 않을 때만 칩을 띄웁니다.
3. 칩을 누르면 현재 지도 `getBounds()` 를 `viewBounds` 로 저장하고 `mapMoved = false`.
   시트가 `peek` 상태면 `half` 로 올립니다 (결과를 봐야 하므로).
4. 목록 필터에 범위 조건을 **첫 단계로** 추가합니다.

```ts
rows = places(kind)
  .filter((r) => !viewBounds ||
    (r.lat >= viewBounds.s && r.lat <= viewBounds.n &&
     r.lng >= viewBounds.w && r.lng <= viewBounds.e))
  .filter(/* 기존 검색어·분류·키워드·재방문·인증 조건 */)
```

5. 범위가 걸린 상태는 §3의 칩 줄 **맨 앞**에 `이 지도 범위` 로 표시합니다.
   조건 칩과 달리 종이 배경 + 테두리(`#fbfaf6` / `#d8d3c8`, 글자 `#6b665e`)로 두어 내용 조건과 구분합니다. 누르면 `viewBounds = null`.
   `모두 지우기` 는 `viewBounds` 까지 함께 해제합니다.

### 주의

- 검색으로 지도를 옮기거나 핀을 눌러 지도가 움직인 경우에는 칩을 띄우지 않습니다. 그 이동은 사용자가 목록을 좁히려고 한 것이 아닙니다. `suppressMoved` 플래그를 세워 그 다음 `moveend` 한 번을 건너뜁니다.
- `viewBounds` 는 저장하지 않습니다. 앱을 다시 열면 해제된 상태입니다.

---

## 5. 손대지 않는 것

- 상단 검색창의 동작 (가게·지역 검색, 지도 이동, 결과 시트)
- 필터 시트 내부 (분류·키워드·재방문·인증 선택 UI)
- 정렬 동작
- 데스크톱 화면
