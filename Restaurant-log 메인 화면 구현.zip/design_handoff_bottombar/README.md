# Handoff: 하단 메뉴바 + 보관함(작성 전 기록)

## Overview
DINARY 모바일 화면에 두 가지를 추가합니다.

1. **하단 메뉴바** — 5칸 고정 탭바. 왼쪽부터 `월력 / 지도 / (카메라) / 커뮤니티 / 내계정`. 가운데 카메라는 바 위로 솟은 원형 단추이고, 누르면 기존 방문 인증 촬영 흐름(`CaptureFlow`)이 열립니다.
2. **보관함** — 사진을 찍고 «나중에 쓸게요»를 누른, 아직 본문을 쓰지 않은 기록만 따로 모으는 화면. 지도 우하단(예전 카메라 FAB 자리)의 원형 단추로 들어가고, 단추 오른쪽 위에 남은 개수 배지가 붙습니다.

## About the Design Files
이 묶음의 HTML은 **디자인 참고물**입니다. 의도한 모양과 동작을 보여주는 시제품이며, 그대로 옮겨 붙일 제품 코드가 아닙니다.
할 일은 이 화면을 대상 코드베이스(`taehyeon-k/restaurant-log` — Next.js App Router + Tailwind v4 + Supabase)의 기존 패턴으로 **다시 만드는 것**입니다. 색·간격·타이포는 이미 `src/app/globals.css` 의 `@theme` 토큰으로 존재하니 새 값을 만들지 말고 토큰을 쓰세요.

## Fidelity
**High-fidelity.** 아래 수치는 시제품에서 실제로 쓰인 값입니다. 픽셀 그대로 재현해 주세요.

---

## Screens / Views

### 1. 하단 메뉴바 (모든 탭에서 항상 보임)

- 컨테이너: `position: absolute; left/right: 0; bottom: 0; height: 74px; z-index: 1170`
  - `background: var(--color-card)` (#fbfaf6), `border-top: 1px solid var(--color-line-soft)` (#e2ddd2)
  - `box-shadow: 0 -2px 14px rgba(28,26,23,.06)`
  - `display: grid; grid-template-columns: repeat(5, 1fr); align-items: start`
  - 실기기에서는 `padding-bottom: env(safe-area-inset-bottom)` 을 더하고 그만큼 높이를 늘릴 것
- 탭 단추 (월력·지도·커뮤니티·내계정 4개):
  - `display:flex; flex-direction:column; align-items:center; gap:4px; height:100%; padding-top:12px`
  - 아이콘 21×21, `stroke: currentColor`, `stroke-width: 1.6`, `fill: none`, 선 끝 round
  - 라벨: JetBrains Mono 9.5px, `letter-spacing: 0.02em`
  - 색: 선택 `var(--color-brick)` #b4552d / 비선택 #a29a8c
  - 아이콘 모양: 월력 = 달력(사각 + 상단 고리 2개 + 점선 3줄), 지도 = 핀(물방울 + 원), 커뮤니티 = 말풍선 + 가운데 선, 내계정 = 원 + 어깨선
- 가운데 카메라 단추:
  - 62×62, `border-radius: 50%`, `background: var(--color-brick)`
  - `border: 3px solid var(--color-card)`, `margin-top: -22px` (바 위로 솟음)
  - `box-shadow: 0 8px 20px rgba(180,85,45,.34)`, hover `background: #9d4826`
  - 안에 기존 `CameraIcon` 26×26 (`ui.tsx` 의 것을 그대로, stroke #fbfaf6)
  - `onClick` → 기존 `setFlow(true)` (CaptureFlow 열기). **아이콘·동작 모두 기존 것 그대로.**
  - 카메라가 잘리지 않도록 바의 `z-index`(1170)가 탭 화면(1160)보다 높아야 함

### 2. 지도 탭 (기존 화면)

- 지도 + 바텀시트 그대로. 시트가 바 위에 얹히도록 시트 컨테이너를 `bottom: 74px` 로 올리고, 최대 스냅 높이를 줄임
  - 시제품 스냅: `peek 192 / half 462 / full 668` (기존 full 742 → 668)
- 지도 위 떠 있는 단추 (시트 높이에 따라 `bottom` 이 `.26s cubic-bezier(.32,.72,0,1)` 로 따라 올라감):
  - `right: 16px` — **보관함**(아래 3번)
  - `right: 84px` — 직접 쓰기 `+` (52×52, `bg card`, `1px solid #d8d3c8`, 아이콘 20×20 stroke #1c1a17)
  - `bottom = min(sheetH + 74 + 14, 700)` / `+` 는 `min(sheetH + 74 + 16, 702)`
- 상단 검색줄 오른쪽에는 **라벨첩** 단추만 남습니다 (보관함은 지도 우하단으로 이동)

### 3. 보관함 단추 (지도 우하단)

- 56×56 원형, `background: var(--color-card)`, `border: 1px solid #d8d3c8`
- `box-shadow: 0 6px 18px rgba(28,26,23,.16)`, hover `border-color: var(--color-brick)`
- 아이콘 23×23, stroke #1c1a17 1.6 — 사진 보관함(카메라 상자): 둥근 사각 `x3.2 y6.6 w17.6 h13.4 r2.6` + 뚜껑 선 `y10.6` + 렌즈 원 `cx12 cy15.3 r2.7` + 상단 돌출 `M8.8 6.6 9.9 4.2h4.2l1.1 2.4`
- **개수 배지** (0개면 숨김): `position:absolute; top:-3px; right:-3px`
  - `min-width:21px; height:21px; padding:0 5px; border-radius:11px`
  - `background: var(--color-brick)`, `border: 2px solid var(--color-paper)` (#f6f3ec)
  - JetBrains Mono 10.5px, `color: #fbfaf6`, `line-height: 1`
  - 값 = 작성 전 기록 전체 개수 (맛집/카페 구분 없음)

### 4. 보관함 화면 (전체 덮는 오버레이, `z-index: 1400`)

`LabelBook` 화면과 같은 골격입니다.

- 배경 `var(--color-paper)`, 좌상단 44×44 원형 `←` (top `max(48px, env(safe-area-inset-top)+6px)`, left 14px)
- 머리: top 104px / left·right 22px
  - eyebrow: JetBrains Mono 10px, `letter-spacing:.22em`, `color: var(--color-faint)`, 글자 `DRAFTS`
  - 제목: Gowun Batang 26px/700 — `보관함`
  - 부제: 12px `var(--color-faint)` — `아직 쓰지 않은 기록 N개` / 없으면 `비어 있습니다`
- 목록: top 196px, `overflow-y:auto`, `padding: 0 20px 40px`, 카드 사이 `gap: 10px`
- 카드 (한 건):
  - `display:flex; gap:12px; align-items:center; padding:12px`
  - `border: 1px solid #e0c3b1` (인증된 기록의 테두리색), `border-radius: 20px`, `background: var(--color-card)`
  - 사진 64×64 `border-radius:15px` — 사진 없으면 카테고리 색 45° 스트라이프(기존 `photoFill`)
    - 오른쪽 아래 −3px 위치에 22×22 인증마크(`VerifiedMark`, 24각 버스트 + 체크 10×10)
  - 가게명: Gowun Batang 15.5px/700, 한 줄 말줄임
  - 메타: JetBrains Mono 10.5px `var(--color-faint)` — `2026.09.06 13:24 · 인증됨`
  - 단추 두 개 (`gap: 8px`, 위 `margin-top: 8px`)
    - `기록 쓰기` — `background: var(--color-ink)`, `color: var(--color-card)`, `padding: 8px 14px`, `border-radius: 15px`, 12px. → 그 기록의 수정 화면(`EditScreen`) 열기
    - `버리기` — 투명 배경, 12px `#a29a8c`, hover `#9a4a52`. → 그 기록 삭제
- 빈 상태: `padding: 44px 20px`, 가운데 정렬, 12.5px `line-height:1.8` `var(--color-faint)`
  - `아직 쓰지 않은 기록이 없습니다. / 사진을 찍고 «나중에 쓸게요»를 누르면 여기에 담깁니다.`

### 5. 다른 탭 (월력 / 커뮤니티 / 내계정)

- 지도도 시트도 보이지 않는 **한 화면**만 뜹니다 (스크롤 없음)
- `position:absolute; top:0; left/right:0; bottom:74px; z-index:1160; background: var(--color-paper)`
- 가운데 정렬, `gap: 10px`
  - 제목: Gowun Batang 19px/700 — 탭 이름 (`월력` / `커뮤니티` / `내계정`)
  - 설명: 12.5px `var(--color-faint)` — `이 화면은 아직 만들지 않았습니다`
- 하단 바는 계속 보이고, 카메라 단추도 그대로 눌립니다

---

## Interactions & Behavior

- 탭 전환은 즉시(전환 애니메이션 없음). 지도 탭으로 돌아오면 이전 시트 상태·선택이 유지됩니다.
- 카메라 단추: 어느 탭에서도 `CaptureFlow` 를 엽니다. 촬영 → 근처 가게 선택 → 인증 완료 화면까지 기존 흐름 그대로.
- 인증 완료 화면의 두 단추 동작이 갈립니다.
  - `이어서 기록 쓰기` → 기록을 만들고 바로 `EditScreen` (지금과 같음)
  - `나중에 쓸게요` → 기록을 **작성 전(pending)** 으로 만들고 닫습니다. 목록·지도에는 나타나지 않고 보관함에만 담깁니다. 배지 숫자가 1 늘어납니다.
- 보관함에서 `기록 쓰기` → 그 기록의 `EditScreen`. **저장하면 pending 이 해제**되어 평소 목록·지도에 합류하고 배지가 1 줄어듭니다. 취소하면 pending 유지.
- 보관함에서 `버리기` → 그 기록 삭제(확인 창 없음. 필요하면 팀 규칙에 맞게 추가).
- 시트 높이가 바뀌면 지도 위 두 단추의 `bottom` 이 `.26s cubic-bezier(.32,.72,0,1)` 로 따라 움직입니다.

## State Management

새로 필요한 것:

- `tab: "calendar" | "map" | "community" | "account"` — 기본 `"map"` (`MobileShell` 로컬 state)
- `draftsOpen: boolean` — 보관함 오버레이
- 기록 한 건에 `pending: boolean` 필드 (아래 데이터 변경)

파생값:

- `pendingRows = rows.filter(r => r.pending)` → 배지 숫자, 보관함 목록
- 목록·지도·필터·정렬에 넘기는 데이터는 **모두 pending 을 제외**해야 합니다.
  `src/lib/places.ts` 의 `groupPlaces` 에 들어가기 전에 걸러내는 편이 안전합니다:
  `groupPlaces(rows.filter(r => r.kind === kind && !r.pending))`
- 시트 머리의 `가게 N · 기록 M` 의 M(기록 수)도 pending 제외
- 라벨첩 계산(`earnedLabels`)은 pending 을 **포함**합니다 (인증은 이미 일어난 일)

## 데이터 변경 (Supabase + 타입)

```sql
alter table restaurants
  add column pending boolean not null default false;
```

`src/lib/types.ts` 의 `Restaurant` 에 한 줄:

```ts
  /** 사진만 찍고 본문을 아직 쓰지 않은 기록 — 보관함에만 보입니다 */
  pending: boolean;
```

- `CaptureFlow` 에서 «나중에 쓸게요» 로 만드는 행: `pending: true`
- `EditScreen` 저장 payload: `pending: false`
- 촬영 시각을 보관함 메타에 쓰려면 `created_at` 을 그대로 쓰면 됩니다 (시제품은 별도 `shotTime` 을 들고 있지만, 실제 코드에는 이미 `created_at` 이 있습니다)

## Design Tokens (이미 `globals.css` 에 있는 값)

| 이름 | 값 | 쓰임 |
|---|---|---|
| `--color-paper` | #f6f3ec | 화면 배경, 탭 화면 |
| `--color-card` | #fbfaf6 | 바 배경, 카드, 원형 단추 |
| `--color-ink` | #1c1a17 | 본문, `기록 쓰기` 단추 |
| `--color-brick` | #b4552d | 카메라 단추, 선택 탭, 배지 |
| `--color-line` | #d8d3c8 | 원형 단추 테두리 |
| `--color-line-soft` | #e2ddd2 | 바 위쪽 선 |
| `--color-faint` | #8a8377 | eyebrow, 부제 |
| (지정색) | #a29a8c | 비선택 탭 라벨, `버리기` |
| (지정색) | #e0c3b1 | 인증된 기록 카드 테두리 |
| (지정색) | #9a4a52 | `버리기` hover |

- 폰트: 제목 Gowun Batang(serif), 숫자·라벨 JetBrains Mono, 본문 Noto Sans KR
- 라운드: 원형 단추 50%, 카드 20px, 사진 15px, 작은 단추 15px, 배지 11px
- 그림자: 바 `0 -2px 14px rgba(28,26,23,.06)` / 카메라 `0 8px 20px rgba(180,85,45,.34)` / 보관함 단추 `0 6px 18px rgba(28,26,23,.16)`
- z-index: 시트 1100 / 탭 화면 1160 / 하단 바 1170 / 가게·기록 화면 1200·1250 / 보관함·라벨첩 1400·1450 / 필터 1500

## Assets
새 이미지 없음. 아이콘은 모두 위에 적힌 인라인 SVG(선 그림)이고, 카메라 아이콘과 인증마크·돼지(`/piggy.png`)는 기존 `src/app/_components/mobile/ui.tsx` 것을 씁니다.

## Files

| 파일 | 내용 |
|---|---|
| `DINARY 모바일 v4.dc.html` | 시제품 전체 (지도·시트·보관함·라벨첩·인증 흐름·하단 바). 브라우저로 바로 열립니다 |
| `support.js` | 위 파일이 뜨기 위한 런타임. 제품 코드와 무관 |

시제품에서 참고할 지점: 하단 바와 탭 화면은 파일 안 `showTabScreen` / `tabStyle` 로, 보관함은 `showDrafts` / `drafts` / `commitVisit(pending)` 로 찾을 수 있습니다.

### 손댈 저장소 파일

- `src/app/_components/mobile/MobileShell.tsx` — 탭 state, 하단 바 배치, 시트 `bottom: 74px`, 스냅 값, FAB 위치, pending 제외
- 새 파일 `src/app/_components/mobile/TabBar.tsx` — 5칸 바 + 가운데 카메라
- 새 파일 `src/app/_components/mobile/DraftsScreen.tsx` — 보관함 (LabelBook.tsx 를 골격으로)
- `src/app/_components/mobile/CaptureFlow.tsx` — «나중에 쓸게요» 가 `pending: true` 로 저장
- `src/app/_components/mobile/EditScreen.tsx` — 저장 시 `pending: false`
- `src/lib/types.ts`, `src/lib/places.ts` — `pending` 필드와 제외 규칙
