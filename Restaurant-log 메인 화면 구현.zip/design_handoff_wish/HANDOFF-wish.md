# Handoff: 가고싶다(위시) + 재방문 기록 추가

대상 저장소: `taehyeon-k/restaurant-log` (main)
시제품: `DINARY 모바일 v4.dc.html` (브라우저에서 열어 동작 확인 — `support.js`, `public/piggy.png` 필요)
완성도: 하이파이. 아래 수치는 최종값입니다. `globals.css` 에 같은 계열 토큰이 있으면 그것을 우선하세요.

종이색 `#f6f3ec` / 카드 `#fbfaf6` / 벽돌색 `#b4552d` / 본문 Gowun Batang / 숫자·라벨 JetBrains Mono.

---

## 0. 이번 작업의 원칙

DINARY의 값은 "인증된 내 기록"입니다. 가고 싶은 곳은 기록이 아니라 아직 아무 일도 일어나지 않은 메모입니다.
그래서 **위시는 기록과 같은 테이블·같은 목록에 섞지 않습니다.**

- 위시에는 **인증마크·별점·사진·메뉴 칸이 없습니다.** 쓸 내용이 없으니까요.
- 위시가 기록으로 바뀌는 길은 **그 자리에서 사진을 찍어 인증하는 것 하나뿐**입니다.
  "예정 → 완료" 체크는 만들지 않습니다. 그것을 만들면 인증이 무의미해집니다.
- 지난 예정은 **날짜만 떨어지고** 「언젠가」로 돌아갑니다. 기록이 되지 않습니다.

---

## 1. DB — 새 테이블 `wishes`

```sql
create table public.wishes (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  name        text not null,
  where_text  text,                    -- 동네나 주소 (자유 입력)
  category    text,                    -- labels.ts 의 분류와 같은 어휘
  note        text,                    -- 가고 싶은 이유 + 출처 링크가 섞여 들어옴
  plan_date   date,                    -- 언제 갈지. null 이면 「언젠가」
  notify      boolean not null default false,
  lat         double precision,
  lng         double precision,
  saved_at    timestamptz not null default now(),   -- 담은 시각. 「nn일 만에」의 기준
  created_at  timestamptz not null default now()
);
```

- RLS는 기존 `restaurants` 정책과 같은 모양(본인 행만)으로 둡니다.
- `note` 는 한 덩어리 자유 텍스트입니다. 링크를 따로 칼럼으로 빼지 않았습니다 —
  사용자는 이유와 출처를 섞어 쓰고, 화면에서 첫 URL만 뽑아 「출처 보기」로 보여줍니다.
- `restaurants` 에 컬럼 하나 추가: **`from_wish jsonb`** — 위시에서 온 기록임을 남깁니다.
  `{"saved_at": "2026-05-14", "days": 117, "planned": true}`. 없으면 null.

---

## 2. 위치 — 하단 탭의 커뮤니티 칸

탭이 5칸으로 꽉 차 있어 새 탭은 만들지 않습니다. **커뮤니티 자리를 「가고싶다」로 바꿨습니다.**
탭 아이콘은 **책갈피**(아래 4장의 그 도형). 커뮤니티 기능은 이번 범위에서 빠집니다.

## 3. WishScreen (`src/app/_components/mobile/WishScreen.tsx`)

`absolute inset-x-0 top-0 bottom-[74px] z-[1160] flex flex-col bg-paper`

### 머리 (스크롤되지 않는 고정부, `padding:48px 20px 14px`)
- `WISHLIST` eyebrow (Mono 10px, `letter-spacing:.18em`, `#8a8377`)
- 제목 `가고싶다` (Gowun Batang 22px 700)
- 셈 줄 12px `#a29a8c` — `담아둔 곳 4곳 · 날짜 정한 곳 1곳` (날짜 정한 게 없으면 앞부분만)
- 한 줄 안내 11.5px `#8a8377` — "아직 가지 않은 곳입니다. 인증 도장은 그 자리에서 사진을 찍을 때만 붙습니다."
- **「+ 가고 싶은 곳 담기」 단추가 머리에 있습니다** (목록과 함께 스크롤되지 않음).
  `min-height:48px; border:1px dashed #cdc6b8; border-radius:18px`, 배경 없음, 13px `#6b665e`.
  hover에 벽돌색. 담아둔 곳이 많아도 늘 손에 닿아야 합니다.

### 목록 (`overflow-y-auto`, 패딩 `0 16px 30px`)
두 갈래. 각 갈래 머리는 Mono 10px `letter-spacing:.16em` `#8a8377`.

1. **「날짜를 정한 곳」** — `plan_date` 오름차순. 오늘 이후만.
   카드: `padding:13px 14px; border-radius:20px; background:#fbfaf6; border:1px solid #e0c3b1`
   오른쪽 위에 점선 날짜 칩 — `border:1px dashed #b4552d; border-radius:9px; padding:3px 8px`, Mono 10.5px `#b4552d`, `2026.09.20`
   그 옆 ✕ (26×26 원형) — 누르면 날짜만 지워지고 「언젠가」로 내려갑니다.
2. **「언젠가」** — 날짜 없는 것 + 날짜가 지난 것.
   카드: 배경 없음, `border:1px dashed #ded8cb`, 같은 패딩·radius.
   오른쪽에 「날짜 정하기」 단추 → 누르면 그 자리에서 `<input type="date">` 로 바뀜.

카드 공통
- 이름 Gowun Batang 16px 700
- 메타 11px `#8a8377` — `한식 · 중구 을지로` (분류 · 자리)
- 적어둔 글 Gowun Batang 12.5px, `line-height:1.7`, `#4d4842`, `white-space:pre-wrap`
- 아래 줄: **알림 종 단추**(30×30 원형) + 링크가 있으면 **「출처 보기」**(15px radius, 11px `#6b665e`)
  종이 켜져 있으면 배경 `#f7ece5`, 테두리 `#e0c3b1`, 글자 `#b4552d`. 꺼져 있으면 배경 없음 `#a29a8c`.
  카드에서 바로 켜고 끕니다 (수정 화면에 들어가지 않아도 되게).

### 지난 예정 처리
불러온 뒤 한 번 훑어서 `plan_date < today` 인 것은 **`plan_date` 를 null 로 만듭니다**(DB에도 반영).
아무 말도 걸지 않고 조용히 「언젠가」로 돌아갑니다.

---

## 4. 담기 시트 (WishSheet)

`z-[1500]`, 아래에서 올라오는 시트. `max-height:88%; overflow-y:auto; border-radius:28px 28px 0 0; padding:18px 20px 26px`.
제목 `가고 싶은 곳` (Gowun Batang 18px 700). 항목 사이 `gap:11px`.

1. **가게** — 한 줄 입력, `min-height:46px; border-radius:14px`
2. **자리** — 한 줄 입력 + 오른쪽 **「지도에서 고르기」** 단추(자리가 정해지면 라벨이 `자리 정해짐 · 다시 고르기`, 테두리·글자 벽돌색)
3. **종류** — 칩 9개: 한식 / 일식 / 중식 / 양식 / 분식 / 고기 / 술집 / 카페 / 빵집.
   기존 필터 칩과 같은 스타일. 다시 누르면 해제. 하나만 고릅니다.
4. **「가고 싶은 이유, 어디서 봤는지」** — `rows=6` 큰 자유 칸, Gowun Batang 14px `line-height:1.8`.
   자리표시: "마음껏 적어두세요. 링크를 붙여두면 카드에서 바로 열립니다."
   이유와 출처를 나누지 않고 한 칸에 씁니다. **첫 URL만 정규식으로 뽑아 「출처 보기」 단추로 쓰고, 본문에서는 그 URL을 지워 보여줍니다.**
5. **언제 갈지 (비워도 됩니다)** — `type="date"`
6. **알림 상자** — `border:1px solid #e2c9bb; background:#f9f0e9; border-radius:18px; padding:13px 15px`
   "근처를 지나면 알려주기" 13.5px + 아래 11.5px `#6b665e` "이 가게에만 걸리는 알림입니다."
   오른쪽 50×28 토글(켜짐 `#b4552d`, 꺼짐 `#d8d3c8`, 손잡이 24px 흰 원 + `box-shadow`)

저장 단추: 이름이 비어 있으면 배경 `#e4dfd3` / 글자 `#8a8377` / 라벨 `가게 이름을 적어주세요` 로 눌리지 않음.
이름이 있으면 `#1c1a17` 바탕 `담기`. `min-height:52px; border-radius:20px`.

### 자리 고르기 (SpotPicker, `z-[1600]`)
전체 화면 지도. 머리에 `취소` / `PICK A SPOT` / `이 자리`(벽돌색).
가운데에 **34px 책갈피 도형**을 고정으로 띄우고(pointer-events:none, 흰 테두리 1.4 + drop-shadow),
지도를 움직여 맞춥니다. 아래 안내 상자: "지도를 움직여 가운데 표시를 가게 자리에 맞춰주세요."
「이 자리」를 누르면 지도 중심 좌표를 `lat`/`lng` 로 받고, `where_text` 가 비어 있으면 `지도에서 고른 자리` 로 채웁니다.

---

## 5. 지도 (MapPane)

### 위시 마커 — 기록 핀과 **모양**으로 갈립니다
기록 핀은 채운 물방울, 위시는 **채운 책갈피**입니다. 점선은 쓰지 않습니다(작아지면 안 보임).

```
26×26 svg, fill = 분류색(pinColor), stroke = #fbfaf6 1.6
path: M6.5 2.6h11a1.4 1.4 0 0 1 1.4 1.4v17a.6.6 0 0 1-.95.49L12 16.7l-5.95 4.79a.6.6 0 0 1-.95-.49V4a1.4 1.4 0 0 1 1.4-1.4Z
filter: drop-shadow(0 2px 4px rgba(28,26,23,.28))
아래에 8×2.5 타원 그림자
iconAnchor: [22, 38]
```
이 도형은 하단 탭 아이콘, 담기 시트의 자리 고르기 십자, + 메뉴의 「계획 추가」 표시, 기록 상세의 WISH MET 카드에서 **모두 같은 path** 를 씁니다.

### 마커 필터 (지도 왼쪽 아래)
`둘 다 / 기록만 / 가고싶다만` 세 갈래. 고른 것만 벽돌색 배경 + 종이색 글자.
바깥 그릇: `padding:3px; border-radius:18px; background:rgba(251,250,246,.95); border:1px solid #d8d3c8`,
칸: `min-height:30px; padding:0 11px; border-radius:15px; font-size:11.5px`.
시트 높이에 따라 함께 올라갑니다(기존 FAB과 같은 `bottom` 계산 + `transition:bottom .26s`).
**이 필터는 지도 마커를 실제로 붙였다 떼는 것입니다** — 투명도나 표시만 바꾸는 게 아닙니다.

### 책갈피를 누르면 — WishSheet(그 가게 하나)
기록 핀을 눌렀을 때와 같은 자리(`z-[1400]` 아래 시트)에 뜹니다.
- 책갈피 15px + `가고싶다` (Mono 9.5px `letter-spacing:.18em` 벽돌색)
- 이름 Gowun Batang 22px 700, 메타 11.5px
- 날짜가 있으면 `2026.09.20 갈 예정` 칩 (`border:1px solid #e0c3b1; background:#f9f0e9`)
- 적어둔 글 전체 (Gowun Batang 14px `line-height:1.85`, `white-space:pre-wrap`). 없으면 "적어둔 말이 없습니다."
- 아래 줄: **「여기 왔어요 · 사진 찍기」**(`#1c1a17` 바탕, flex:1) + 알림 종(44px 원형) + 출처(44px 원형, 외부링크 아이콘)
- 맨 아래 「가고싶다 목록에서 보기」 (12px `#8a8377`)

**별점·사진·인증 도장 자리는 없습니다.** 아직 기록이 아닙니다.

### + 단추 → 두 갈래
지금은 +를 누르면 곧바로 기록 입력으로 갑니다. 이제 기록과 계획 둘 다 가능하므로 고르게 합니다.

- 누르면 **+ 단추 자체가 벽돌색으로 차고**(`background:#b4552d`, 아이콘 종이색, `box-shadow:0 8px 20px rgba(180,85,45,.34)`) **아이콘이 45° 돌아 ×가 됩니다**. 눌렸다는 것을 그 자리에서 알려줍니다.
- 위로 두 갈래가 열립니다 (`gap:8px`, 오른쪽 정렬, 카드 `min-height:46px; border-radius:16px; background:#fbfaf6`)
  - **기록 추가** — 앞에 22px 채운 물방울 표시. 기존 기록 입력으로.
  - **계획 추가** — 앞에 20px 책갈피. 가고싶다 담기 시트로.
- 지도 아무 곳이나 누르면 닫힙니다. 시트가 다 올라와 있으면(`full`) 두 갈래가 화면 밖으로 나가므로 `half` 로 내립니다.

---

## 6. 월력 — 예정 얹기

`CalendarScreen` 은 이미 날짜 단위 흐름입니다(이전 handoff). 여기에 **예정을 층으로 얹습니다.**

- **날짜를 정한 위시만** 월력에 뜹니다. 날짜 없는 것은 뜨지 않습니다.
- 칸 안 칩: 기록은 채운 배경, 예정은 배경 `#eee9de` / 글자 `#8a8377` + **앞에 5px 빈 동그라미**(`border:1px solid #b4552d`). 지나간 일과 앞일이 한눈에 갈립니다.
- 칸당 최대 2개 + `+N` 은 그대로. 기록을 먼저, 예정을 뒤에 셉니다.
- 헤더 셈 줄 오른쪽에 **「예정 보임 / 예정 숨김」** 단추 (기본 **켜짐**).
  켜짐: `background:#f7ece5; border:1px solid #e0c3b1; color:#b4552d` + 앞에 6px 빈 동그라미.
  꺼짐: 배경 없음, `#8a8377`. `min-height:30px; border-radius:15px; font-size:11px`.
- 예정만 있는 날을 누르면 → **가고싶다 화면**으로. 기록이 있는 날은 그대로 DayScreen.

---

## 7. 위시가 기록이 되는 순간 — WISH MET

기록을 저장할 때(`saveDraft` 상당), **이름이 같은 위시가 있으면** 그 위시를 기록으로 옮겨 담습니다.

```
from_wish = { saved_at: wish.saved_at, days: 방문일 - saved_at (일수), planned: !!wish.plan_date }
→ 그 wish 행은 삭제
```

- 일수는 **사용자가 고른 방문일** 기준입니다(오늘이 아님). 저장 순서에 주의: `visited_at` 을 먼저 확정한 뒤 계산하세요.
- 기록 상세에 카드가 붙습니다 (`border:1px solid #e0c3b1; background:#f9f0e9; border-radius:20px; padding:15px 16px`)
  - 17px 책갈피 + `WISH MET` (Mono 9.5px 벽돌색)
  - Gowun Batang 14px `line-height:1.75` —
    `2026.05.14에 담아둔 곳입니다. 117일 만에 드디어 다녀오셨네요.`
    같은 날 담고 갔으면 → `담아두고 바로 다녀오셨네요.`
- 담아두길 잘했다는 느낌을 주는 자리입니다. 과장하지 말고 한 문장으로 둡니다.

---

## 8. 같은 가게에 새 방문 더하기

지금은 이미 다녀온 가게로 들어가면 **「기록 수정」밖에 없습니다.** 재방문을 적을 길이 없습니다.

- 기록 상세와 가게 화면 **맨 위에 「여기 또 왔어요 · 기록 추가」**(`#1c1a17` 바탕, `min-height:50px; border-radius:18px`).
  「기록 수정」은 그 아래 테두리 단추(`border:1px solid #ded8cb`, 배경 없음)로 내립니다.
- 누르면 새 기록을 만들어 편집 화면을 엽니다:
  이름·분류·지역·주소·좌표는 그대로 이어받고, `visited_at = 오늘`, `revisit = true`, `verified = false`, 별점·메모는 빈 값.
- **취소하면 그 기록은 지워집니다.** 새로 만든 상태(`isNew` 상당)로 두어, 빈 껍데기 기록이 목록·지도·월력·셈에 남지 않게 하세요. (시제품에서 실제로 났던 버그입니다.)

## 9. 검색 → 지도로 간 뒤 고르기

지금은 검색해서 하나가 맞으면 곧바로 그 가게 화면으로 들어가 버립니다.

- 이제 **지도가 그 자리로 날아가고(zoom 16, `duration .7`)**, 아래에 작은 시트가 뜹니다.
  - `찾았습니다` (Mono 9.5px) / 이름 22px / 메타 11.5px / `기록 3건 · 마지막 2026.06.28` (Mono 10.5px `#a29a8c`)
  - **「여기 또 왔어요 · 기록 추가」**(짙은 단추) / 「지난 기록 보기」(테두리 단추)
- 지도를 누르면 닫히고 **그 자리에 그대로 머무릅니다**(원래 화면으로 튕기지 않음).
- 검색 결과가 여럿이면 기존대로 `fitBounds` 로 다 보여줍니다.

---

## 10. 알림 (미구현 — 설계만)

시제품에는 **토글까지만** 있습니다. 실제 위치 알림은 앱 권한·백그라운드 처리라 저장소 쪽 작업입니다.

- 가게별로 켜고 끕니다(전체 스위치 하나가 아님). `wishes.notify`.
- 사용자 요청: "근처를 지나가면 알려주는 건 좋은데, 그것도 식당별로 알람을 설정할 수 있으면 좋겠다."
- 켜진 위시 중 `lat/lng` 가 있는 것만 대상입니다. 같은 곳에 대해 반복해서 울리지 않게 마지막 알림 시각을 남겨두세요.

---

## 11. 접점 정리

- 새 파일: `WishScreen.tsx`, `WishSheet.tsx`(가게 하나 시트), `WishForm.tsx`(담기), `SpotPicker.tsx`
- `TabBar.tsx` — 커뮤니티 칸을 「가고싶다」+책갈피 아이콘으로
- `MapPane.tsx` — 위시 마커 레이어, 마커 필터 세 갈래, + 단추 두 갈래 메뉴
- `CalendarScreen.tsx` — 예정 칩, 「예정 보임/숨김」 단추
- `RecordScreen.tsx` / `PlaceScreen.tsx` — WISH MET 카드, 「여기 또 왔어요 · 기록 추가」
- `MobileShell.tsx` — wish 상태·라우팅(`/?wish=<id>` 로 시트를 표현하면 뒤로 가기가 자연스럽습니다)
- `src/lib/queries.ts` — `wishes` CRUD + 지난 예정 훑기
- 마이그레이션 — `wishes` 테이블, `restaurants.from_wish`
