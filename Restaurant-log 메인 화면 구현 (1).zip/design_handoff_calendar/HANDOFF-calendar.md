# Handoff: 월력 — 날짜 단위로 여는 그날의 기록

대상 저장소: `taehyeon-k/restaurant-log` (main)
고칠 파일: `src/app/_components/mobile/CalendarScreen.tsx`
새로 만들 파일: `src/app/_components/mobile/DayScreen.tsx`
연결 지점: `src/app/_components/mobile/MobileShell.tsx`

## 왜 바꾸는가
지금 월력은 달력 칸 안의 가게 이름 하나하나가 버튼이라 그 기록으로 바로 갑니다.
칸 안 이름은 9px 안팎이라 손가락으로 정확히 고르기 어렵습니다.
**클릭 단위를 가게에서 날짜로 올립니다.** 칸 안 이름은 미리보기(비활성 텍스트)가 되고,
칸 전체를 누르면 「N월 N일 방문한 식당」 화면이 열려 그날 기록이 큰 카드로 모입니다.

## 이 폴더의 파일
`DINARY 모바일 v4.dc.html` 은 **HTML 시제품(디자인 참고물)** 입니다. 그대로 붙이는 프로덕션 코드가 아닙니다.
브라우저에서 열고 하단 `월력` 탭 → 기록 있는 날짜를 눌러 동작을 먼저 확인하세요 (`support.js`, `public/piggy.png` 필요).
데이터 접근은 저장소의 기존 방식(`src/lib/queries.ts`, `types.ts`, `price.ts`)을 그대로 씁니다. 시제품의 SEED 데이터는 버립니다.

완성도: **하이파이**. 아래 수치는 최종값입니다. 저장소에 이미 있는 색 토큰(`globals.css`)이 있으면 그것을 우선하세요 — 값은 같은 계열입니다.

---

## 1. CalendarScreen 수정

### 유지
- 화면 위치 `absolute inset-x-0 top-0 bottom-[74px] z-[1160] bg-paper`
- `CALENDAR` eyebrow → `{year}년 {month}월` 제목 → ‹ / 오늘 / › 단추 → "이 달 기록 N건"
- 일요일 시작, 앞뒤를 채운 온전한 주 격자, 주 단위 행이 남은 높이를 균등 분할
- `visited_at` 문자열("YYYY-MM-DD") 그대로 날짜 키로 사용

### 바뀌는 것
1. **칸 전체가 버튼**입니다. 안의 가게 이름은 `<span>`(버튼 아님).
   - 기록이 있는 날: `cursor:pointer`, 누르면 `onOpenDay(dateKey)`
   - 기록이 없는 날, 이번 달이 아닌 칸: 핸들러 없음, `cursor:default`
2. **이름 칩** — 최대 2개 + 나머지는 `+N`
   - 4글자 초과 시 `이름.slice(0,4) + "…"` (CSS 말줄임 대신 직접 자름)
   - 칩: `display:block; width:100%; border-radius:5px; padding:2px 3px; font-size:9px; line-height:1.35; white-space:nowrap; overflow:hidden; text-align:left`
   - 인증된 기록: 배경 `#f2e0d5`, 글자 `#a34d27` / 인증 없는 기록: 배경 `#eae5da`, 글자 `#6b665e`
   - `+N` 줄: JetBrains Mono 8.5px, `#a29a8c`
   - 칩 묶음: 날짜 숫자 아래 `margin-top:4px`, `flex-direction:column; gap:2px`, `overflow:hidden`
3. **인증 시각 표시 제거** — 칸 안에서는 시각을 보여주지 않습니다(그날 화면에서 보여줄 수 있음). 화면 폭에 따라 글자 수를 늘리던 `useMediaQuery` 분기도 함께 정리합니다.

### 칸 스타일 (최종값)
- `flex:1; min-width:0; min-height:0; overflow:hidden; padding:5px 4px; border-radius:12px; text-align:left`
- 이번 달: 배경 `#fbfaf6`, 테두리 `1px solid #e6e0d3`
- 이번 달 아님: 배경 없음, 테두리 `1px solid transparent`
- 오늘: 테두리 `1.5px solid #b4552d`
- 격자 여백: 행 사이 `gap:4px`, 칸 사이 `gap:4px`, 좌우 패딩 12px
- 날짜 숫자: JetBrains Mono 10.5px / 이번 달 아님 `#cfc8ba` / 오늘 `#b4552d` 700 / 그 외 `#1c1a17`

### 첫 화면 달
현재 달이 비어 있으면 첫 화면이 텅 빕니다. **가장 최근 기록(`visited_at` 최댓값)이 있는 달**로 엽니다.
사용자가 ‹ › 로 달을 옮긴 뒤에는 그 선택을 따릅니다(커서 state가 있으면 그 값 우선).

```ts
const cursor = state ?? monthOf(maxVisitedAt ?? new Date());
```

---

## 2. DayScreen (새 화면)

`absolute inset-0 z-[1190] flex flex-col bg-paper` — 월력 위, 기록 상세(z 1250) 아래.

### 머리
- 패딩 `44px 20px 16px`, 아래 테두리 `1px solid #e6e0d3`
- ← 단추: 44×44 원형, 배경 없음, 17px `#1c1a17`, `margin-left:-10px` (글자 왼쪽 선 맞춤), hover 배경 `#eee9de`
- 날짜 줄: JetBrains Mono 10px, `letter-spacing:.18em`, `#8a8377` — `2026.08.09` (점 구분)
- 제목: Gowun Batang 26px 700, `letter-spacing:-.01em` — **`8월 9일 방문한 식당`**
- 부제: 12px `#a29a8c` — `기록 N건`

### 목록
`overflow-y-auto`, 패딩 `14px 16px 40px`, 카드 사이 `gap:10px`.
카드는 메인 시트의 `PlaceCard` 와 같은 골격입니다 (그쪽 컴포넌트를 그대로 쓰거나 스타일을 맞추세요).

- 카드: `display:flex; align-items:flex-start; gap:12px; width:100%; padding:12px; border-radius:22px; background:#fbfaf6`
  테두리 — 인증된 기록 `1px solid #e0c3b1`, 그 외 `1px solid #e4dfd3`
- 사진: 72×72, `border-radius:18px`, 기존 `photoFill` 규칙. 사진이 없으면 분류색 사선 자리표시 + `PHOTO` 라벨(Mono 9px, `rgba(251,250,246,.9)`)
- 인증마크: 사진 오른쪽 아래 `right:-3px; bottom:-3px`, 24×24 (`VerifiedMark size={24}`)
- 이름: Gowun Batang 16px 700 / 옆에 `재방문` 배지(배경 `#f7ece5`, 글자 `#b4552d` 9.5px, radius 9px, 패딩 `2px 7px`)
- 분류·지역: 11px `#8a8377` — `한식 · 서울 중구`
- 별점: 12.5px 별 + Mono 10.5px 숫자 `#6b665e` (기존 별 겹침 방식 그대로)
- 메모: 11.5px `#4d4842`, `line-height:1.5`, 2줄에서 자름(`-webkit-line-clamp:2`). 메모가 없으면 메뉴, 둘 다 없으면 `메모가 비어 있습니다`

### 정렬
그날 기록은 **가게 이름 오름차순**. (인증 시각순으로 바꾸려면 `verified_at` 기준으로 두세요 — 정렬 규칙만 바꾸면 됩니다.)

---

## 3. 뒤로 가기 규칙

기록 상세(`RecordScreen`)에서 ←:
- **그날 화면에서 들어왔으면** → 그날 화면으로 돌아갑니다(월력까지 가지 않음).
- 가게 화면에서 들어왔으면 → 기존 동작 그대로(방문이 여럿이면 가게 화면).

시제품은 `dayKey` 가 살아 있는 동안 `visitId` 만 비우는 방식으로 처리했습니다. 저장소에서는 라우팅 방식에 맞춰
`/?day=YYYY-MM-DD` 쿼리로 그날 화면을 표현하고, 기록은 `/?day=...&rid=...` 로 얹는 편이 자연스럽습니다.
하단 탭을 다른 탭으로 옮기면 `day` 를 비웁니다.

---

## 4. 인증 시각 자동 표시 (`verified_at`)

`supabase/migrations/20260907000000_add_restaurants_verified_at.sql` 로 이미 DB 시계에서 찍히는 `verified_at` 이 있습니다.
**인증된 기록은 어디서든 날짜 뒤에 그 시각(HH:MM)을 자동으로 붙입니다.** 클라이언트가 시각을 입력하거나 고치는 길은 없습니다.

- 표기: `2026.06.28 13:24` (날짜는 점, 시각은 24시간 `HH:MM`, 모두 JetBrains Mono)
- 붙는 곳
  1. `RecordScreen` 의 `방문` 항목
  2. `PlaceScreen` 의 방문 이력 카드 날짜 줄
  3. `DayScreen` 카드 — 별점 오른쪽에 세로 구분선(1×11 `#ded8cb`) + 시각 `#b4552d` 10.5px
- 인증이 없는 기록(직접 쓴 기록)은 날짜만. 시각 자리에 `—` 같은 대체 문자를 넣지 않습니다.
- `EditScreen` 의 `방문일`
  - 인증된 기록: 날짜 입력칸을 **읽기 전용 도장 줄**로 대체합니다.
    `min-height:48px; border:1px solid #e0c3b1; border-radius:16px; background:#f9efe8; padding:0 15px`,
    왼쪽에 20×20 인증마크(`VerifiedMark size={20}`), 그 옆 Mono 13.5px `2026.06.28 13:24`,
    아래 도움말 11.5px `#8a8377` — "사진을 찍은 시각이 그대로 찍혀 고칠 수 없습니다."
    저장 요청에서 `visited_at` / `verified_at` 을 아예 보내지 않습니다.
  - 인증이 없는 기록: 기존 `type="date"` 입력칸 그대로.
- 시각 값은 `verified_at` 을 사용자 시간대로 변환해 `HH:MM` 으로 만듭니다(기존 `verifiedHour` 를 분까지 나오게 확장하거나 새 헬퍼 추가).
  시제품에서는 `shotTime`(촬영 시각 문자열)으로 대신했습니다.

## 5. 접점 정리
- `CalendarScreen` props: `rows` 유지, `onOpenVisit` → **`onOpenDay(dateKey: string)`** 로 교체
- `MobileShell`: `day` 상태(또는 쿼리) 추가, `DayScreen` 렌더, `DayScreen.onOpenRecord` → 기존 기록 상세 열기 재사용
- `verifiedHour` 는 월력에서 더 이상 쓰지 않습니다. DayScreen에서 시각을 노출하려면 카드 메타 줄에 붙이세요(현재 디자인에는 없음).
